<form method="post" class="form-inline" role="form" class="pagination-centered" action="result.php">
    <div class="form-group" >
      <input type="text" name="area"  size="100" class="form-control" id="search" placeholder="Enter Area">
      <input type="submit" class="btn btn-xl btn-danger" name="search" value="Find Restaurants">
    </div>
</form>