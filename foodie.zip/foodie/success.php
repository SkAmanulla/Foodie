<html>
	<h1 align=" center"> Successfull!</h1>
	<div style="margin-left: 400px;">
	<img src="images/success.png" align="center">
	</div>
</html>
	<?php
	header('Refresh: 1; URL = index.php');
?>